
import os

class blocks:
    def __init__(self):
        self.diffuclty_name = None
        self.enemy_dic = []

    def generate_random_block(self,argDifficultyFamily="Easy"):
        print("to be implementd")

    def shape_game_scenario(self):
        print("to be implementd")

    def save_game_scenario(self):
        print("to be implementd")

    def load_game_scenario(self):
        print("to be implementd")

    def set_enemy_dic(self):
        self.enemy_dic.append({"color": "blue", "shape": "circle", "moveset": 1})
        self.enemy_dic.append({"color": "yellow", "shape": "square", "moveset": 2})
        self.enemy_dic.append({"color": "red", "shape": "triangle", "moveset": 3})





